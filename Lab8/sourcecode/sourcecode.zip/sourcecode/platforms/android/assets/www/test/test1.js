describe('our first test',function(){
it(' sum',function(){
var sum=10+20;
expect(sum).toEqual(30);
});
});